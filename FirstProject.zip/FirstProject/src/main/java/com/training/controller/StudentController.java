package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.dto.StudentSearchDTO;
import com.training.model.StudentEntity;
import com.training.service.StudentSearchService;

@RestController
public class StudentController {

	@Autowired
	StudentSearchService service;

	@GetMapping("/students")
	public List<StudentSearchDTO> getStudents() {
		return service.getStudents();
	}
//	api should be noun not verb

	@GetMapping("/student/{id}")
	public StudentEntity getstudentbyId(@PathVariable Integer id) {
		return service.getstudentbyId(id);
	}

	// browser only excepts GET so DELETE will give fallback so.
	// use postman or thunderclient for DELETE API
	@DeleteMapping("/student/{id}")
	public void deletebyId(@PathVariable Integer id) {
		service.deletestudentbyId(id);
	}

	@PostMapping("/student")
	public void insertstudent(StudentEntity student) {
		service.saveStudent(student);
	}

	@PutMapping("/student")
	public void updatestudent(StudentEntity student) {
		service.saveStudent(student);
	}

}
