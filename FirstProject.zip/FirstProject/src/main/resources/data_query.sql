INSERT INTO app.STUDENT(student_id,dob,name,yoa) values(1,'10/12/2016','dinesh','2012')
INSERT INTO app.STUDENT(student_id,dob,name,yoa) values(2,'10/13/2016','sai','2012')
INSERT INTO app.STUDENT(student_id,dob,name,yoa) values(3,'10/14/2016','venkat'	,'2012')

INSERT INTO app.STUDENT_MARKS(STUDENT_ID,MATHS,PHYSICS,CHEMISTRY) values(1,55,70,50)
INSERT INTO app.STUDENT_MARKS(STUDENT_ID,MATHS,PHYSICS,CHEMISTRY) values(2,55,40,70)
INSERT INTO app.STUDENT_MARKS(STUDENT_ID,MATHS,PHYSICS,CHEMISTRY) values(3,35,70,50)

INSERT INTO app.CONTACT (STUDENT_ID,MOBILE_NO,EMAIL,ADDRESS) values(1,'6677','dmail@email.com','bangalore')
INSERT INTO app.CONTACT (STUDENT_ID,MOBILE_NO,EMAIL,ADDRESS) values(2,'7995','saimail@email.com','hyderabad')
INSERT INTO app.CONTACT (STUDENT_ID,MOBILE_NO,EMAIL,ADDRESS) values(3,'9245','vmail@email.com','chennai')